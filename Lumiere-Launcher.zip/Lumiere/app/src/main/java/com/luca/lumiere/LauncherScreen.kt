package com.luca.lumiere

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LauncherScreen(
    apps: List<TvApp>,
    onLaunch: (TvApp) -> Unit,
    onTogglePin: (TvApp) -> Unit,
) {
    MaterialTheme(colorScheme = darkColorScheme()) {
        val homeApps = remember(apps) { apps.filter { !it.store } }
        val storeApps = remember(apps) { apps.filter { it.store } }

        val homeState = rememberLazyListState()
        val storeState = rememberLazyListState()
        val scope = rememberCoroutineScope()
        val requesters = remember { mutableMapOf<String, FocusRequester>() }
        var focusedKey by remember { mutableStateOf<String?>(null) }
        var pendingFocus by remember { mutableStateOf<String?>(null) }
        var initialDone by remember { mutableStateOf(false) }
        var moveDir by remember { mutableStateOf(0) }
        var lastIndex by remember { mutableStateOf(0) }

        val focused = apps.firstOrNull { it.key == focusedKey } ?: apps.firstOrNull()
        val accent by animateColorAsState(
            targetValue = focused?.accent ?: Color(0xFF2C2C2E),
            animationSpec = tween(700),
            label = "accent",
        )
        val (date, time) = rememberClock()

        // Focus initial sur la première app, puis focus conservé après un (dés)épinglage.
        LaunchedEffect(homeApps) {
            if (homeApps.isEmpty()) return@LaunchedEffect
            val target = pendingFocus
                ?: if (!initialDone) homeApps.first().key else return@LaunchedEffect
            val index = homeApps.indexOfFirst { it.key == target }.coerceAtLeast(0)
            homeState.scrollToItem(index)
            delay(120)
            runCatching {
                requesters.getOrPut(homeApps[index].key) { FocusRequester() }.requestFocus()
            }
            pendingFocus = null
            initialDone = true
        }

        // Centre l'app sélectionnée à l'écran, comme sur Apple TV.
        val centerOn: (LazyListState, Int) -> Unit = { state, index ->
            scope.launch {
                val info = state.layoutInfo
                val item = info.visibleItemsInfo.firstOrNull { it.index == index }
                    ?: return@launch
                val viewportCenter = (info.viewportStartOffset + info.viewportEndOffset) / 2f
                val itemCenter = item.offset + item.size / 2f
                state.animateScrollBy(itemCenter - viewportCenter)
            }
        }

        val onTileFocused: (TvApp, LazyListState, Int) -> Unit = { app, state, index ->
            focusedKey = app.key
            moveDir = (index - lastIndex).coerceIn(-1, 1)
            lastIndex = index
            centerOn(state, index)
        }

        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .drawBehind {
                    drawRect(
                        Brush.radialGradient(
                            colors = listOf(accent.copy(alpha = 0.9f), Color.Transparent),
                            center = Offset(size.width * 0.25f, size.height * 0.15f),
                            radius = size.maxDimension * 0.85f,
                        )
                    )
                }
        ) {
            val w = maxWidth
            val pad = w * 0.06f
            val tileWidth = w * 0.15f

            // Fond « artwork » flouté de l'app sélectionnée, comme sur tvOS.
            Crossfade(
                targetState = focused,
                modifier = Modifier.fillMaxSize(),
                animationSpec = tween(600),
                label = "backdrop",
            ) { app ->
                val art = app?.blurred
                if (art != null) {
                    Image(
                        bitmap = art,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        alpha = 0.55f,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
            // Voile sombre pour garder le texte lisible.
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = 0.15f),
                                Color.Black.copy(alpha = 0.7f),
                            )
                        )
                    )
            )

            Column(Modifier.fillMaxSize()) {
                // Barre du haut : date + heure
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = pad, vertical = w * 0.015f),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        date,
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = (w.value * 0.016f).sp,
                    )
                    Text(
                        time,
                        color = Color.White,
                        fontSize = (w.value * 0.022f).sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }

                // Zone « héros » : nom et description de l'app sélectionnée
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = pad),
                    verticalArrangement = Arrangement.Bottom,
                ) {
                    Text(
                        focused?.label.orEmpty(),
                        color = Color.White,
                        fontSize = (w.value * 0.045f).sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    val sub = focused?.tagline
                        ?: if (focused?.pinned == true) "★ Épinglée" else null
                    if (sub != null) {
                        Text(
                            sub,
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = (w.value * 0.015f).sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                SectionTitle("Mes apps", w, pad)
                LazyRow(
                    state = homeState,
                    contentPadding = PaddingValues(horizontal = pad, vertical = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(w * 0.02f),
                ) {
                    itemsIndexed(homeApps, key = { _, app -> app.key }) { index, app ->
                        AppTile(
                            app = app,
                            width = tileWidth,
                            requester = requesters.getOrPut(app.key) { FocusRequester() },
                            tilt = { moveDir },
                            onFocused = { onTileFocused(app, homeState, index) },
                            onLaunch = { onLaunch(app) },
                            onPin = {
                                if (app.key != AppRepository.SETTINGS_KEY) {
                                    pendingFocus = app.key
                                    onTogglePin(app)
                                }
                            },
                        )
                    }
                }

                if (storeApps.isNotEmpty()) {
                    SectionTitle("Découvrir  ·  Appstore Amazon", w, pad)
                    LazyRow(
                        state = storeState,
                        contentPadding = PaddingValues(horizontal = pad, vertical = 14.dp),
                        horizontalArrangement = Arrangement.spacedBy(w * 0.02f),
                    ) {
                        itemsIndexed(storeApps, key = { _, app -> app.key }) { index, app ->
                            AppTile(
                                app = app,
                                width = tileWidth,
                                requester = requesters.getOrPut(app.key) { FocusRequester() },
                                tilt = { moveDir },
                                onFocused = { onTileFocused(app, storeState, index) },
                                onLaunch = { onLaunch(app) },
                                onPin = {},
                            )
                        }
                    }
                }

                Text(
                    "OK  ouvrir      ☰  épingler / désépingler",
                    color = Color.White.copy(alpha = 0.45f),
                    fontSize = (w.value * 0.011f).sp,
                    modifier = Modifier.padding(horizontal = pad, vertical = w * 0.008f),
                )
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, w: Dp, pad: Dp) {
    Text(
        title,
        color = Color.White.copy(alpha = 0.6f),
        fontSize = (w.value * 0.013f).sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(horizontal = pad),
    )
}

@Composable
private fun AppTile(
    app: TvApp,
    width: Dp,
    requester: FocusRequester,
    tilt: () -> Int,
    onFocused: () -> Unit,
    onLaunch: () -> Unit,
    onPin: () -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    LaunchedEffect(focused) { if (focused) onFocused() }

    val scale by animateFloatAsState(
        targetValue = if (focused) 1.14f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessLow),
        label = "scale",
    )
    val lift by animateFloatAsState(
        targetValue = if (focused) 1f else 0f,
        animationSpec = tween(220),
        label = "lift",
    )
    val shape = RoundedCornerShape(width * 0.06f)
    val img = app.image

    Column(Modifier.width(width), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationY = -12.dp.toPx() * lift
                    // Léger basculement vers la direction du déplacement, façon tvOS.
                    rotationY = tilt() * 8f * lift
                    cameraDistance = 14f * density
                    shadowElevation = 48f * lift
                    this.shape = shape
                    clip = false
                }
                .border(BorderStroke(3.dp, Color.White.copy(alpha = lift)), shape)
                .focusRequester(requester)
                .onKeyEvent { e ->
                    if (e.key == Key.Menu && e.type == KeyEventType.KeyUp) {
                        onPin()
                        true
                    } else {
                        false
                    }
                }
                .clickable(
                    interactionSource = interaction,
                    indication = null,
                    onClick = onLaunch,
                )
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(shape)
                    .background(
                        Brush.linearGradient(
                            listOf(app.accent, lerp(app.accent, Color.Black, 0.55f))
                        )
                    ),
                contentAlignment = Alignment.Center,
            ) {
                when {
                    img == null -> GlyphContent(app, width)
                    app.isBanner -> Image(
                        bitmap = img,
                        contentDescription = app.label,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                // Parallaxe : l'image glisse légèrement dans la tuile.
                                scaleX = 1.12f
                                scaleY = 1.12f
                                translationX = tilt() * -6.dp.toPx() * lift
                            },
                    )
                    else -> Image(
                        bitmap = img,
                        contentDescription = app.label,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxHeight(0.62f)
                            .aspectRatio(1f)
                            .graphicsLayer { translationX = tilt() * -4.dp.toPx() * lift },
                    )
                }

                // Reflet brillant quand la tuile est sélectionnée
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color.White.copy(alpha = 0.25f * lift),
                                    Color.Transparent,
                                )
                            )
                        )
                )

                if (app.pinned) {
                    Text(
                        "★",
                        color = Color.White,
                        fontSize = (width.value * 0.05f).sp,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .background(Color.Black.copy(alpha = 0.45f), CircleShape)
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Text(
            app.label,
            color = Color.White,
            fontSize = (width.value * 0.075f).sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.graphicsLayer { alpha = lift },
        )
    }
}

@Composable
private fun GlyphContent(app: TvApp, width: Dp) {
    val big = app.glyph.length <= 2
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            app.glyph,
            color = Color.White,
            fontSize = (width.value * (if (big) 0.3f else 0.1f)).sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            maxLines = 2,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        val badge = app.badge
        if (badge != null) {
            Text(
                badge,
                color = Color.White.copy(alpha = 0.7f),
                fontSize = (width.value * 0.05f).sp,
            )
        }
    }
}

@Composable
private fun rememberClock(): Pair<String, String> {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(15_000)
        }
    }
    val date = remember(now) {
        SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(now)
            .replaceFirstChar { it.uppercase() }
    }
    val time = remember(now) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(now) }
    return date to time
}
