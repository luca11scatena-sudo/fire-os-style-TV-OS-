# Lumière — launcher style Apple TV pour Fire TV

## Compiler
1. Installe Android Studio (Koala ou plus récent).
2. File > Open > dossier `Lumiere`, attends la synchro Gradle.
3. Build > Build APK(s) → `app/build/outputs/apk/debug/app-debug.apk`.

## Installer sur la Fire TV
1. Fire TV : Paramètres > Ma Fire TV > À propos > clique 7 fois sur le nom de l'appareil.
2. Paramètres > Ma Fire TV > Options pour les développeurs : active « Débogage ADB » et « Applis de sources inconnues ».
3. Note l'IP (À propos > Réseau), puis sur ton PC :
   adb connect IP_DE_LA_FIRE_TV:5555
   adb install app-debug.apk
4. Lance « Lumière » depuis Vos applications.

## Sans PC : compiler avec GitHub et installer avec Downloader
1. Crée un dépôt GitHub PUBLIC (branche main) et envoie-y tout le contenu du dossier Lumiere
   (y compris le dossier .github).
2. L'onglet Actions compile l'APK tout seul (environ 5 min). Si ça échoue, ouvre l'étape en
   erreur et copie le message.
3. Quand c'est vert, l'APK est dans Releases > latest. Son lien direct est :
   https://github.com/TON_PSEUDO/TON_DEPOT/releases/download/latest/app-debug.apk
4. Sur la Fire TV, installe l'app « Downloader », autorise-la à installer des apps inconnues
   (Paramètres > Ma Fire TV > Options pour les développeurs), saisis le lien et installe.

## Utilisation
- Flèches : naviguer (haut/bas pour changer de rangée), OK : ouvrir, bouton ☰ (Menu) : épingler / désépingler.
- Retour ne ferme pas le launcher.

## Découvrir (store)
La deuxième rangée propose des raccourcis vers l'Appstore Amazon : OK ouvre la fiche de l'app
(ou une recherche), et tu installes depuis l'Appstore. Les apps déjà installées disparaissent
de cette rangée. La tuile « Appstore Amazon » ouvre le catalogue complet. Pour ajouter une app,
modifie la liste CATALOG dans AppRepository.kt.

## Remplacer l'accueil Amazon
Fire OS n'offre pas de choix officiel du launcher par défaut. Le bouton Home renvoie donc
vers l'accueil Amazon. Options : lancer Lumière depuis Vos applications, ou remapper le
bouton Home avec une app comme Button Mapper. Désactiver le launcher Amazon via ADB
(`pm disable-user`) est possible mais risqué ; pour annuler :
   adb shell pm enable com.amazon.tv.launcher
