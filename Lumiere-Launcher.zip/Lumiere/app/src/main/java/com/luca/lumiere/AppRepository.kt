package com.luca.lumiere

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import android.graphics.Color as AndroidColor

data class TvApp(
    val key: String,          // nom du package, "__settings__" ou "store:..."
    val label: String,
    val intent: Intent,
    val image: ImageBitmap?,  // bannière ou icône ; null = on dessine `glyph`
    val isBanner: Boolean,
    val accent: Color,        // couleur dominante, sert à teinter le fond
    val pinned: Boolean = false,
    val glyph: String = "",   // texte dessiné dans la tuile quand il n'y a pas d'image
    val badge: String? = null,
    val tagline: String? = null,
    val store: Boolean = false, // true = raccourci vers l'Appstore Amazon
    val blurred: ImageBitmap? = null, // version floutée, pour le fond
)

private data class StoreEntry(
    val name: String,
    val tagline: String,
    val color: Long,
    val pkg: String? = null,   // si connu : ouvre directement la fiche de l'app
)

object AppRepository {
    private const val PREFS = "lumiere"
    private const val PINNED = "pinned"
    const val SETTINGS_KEY = "__settings__"
    private const val APPSTORE_PKG = "com.amazon.venezia"
    private val FALLBACK = Color(0xFF3A3A3C)

    // Catalogue de raccourcis. Sans package connu, on ouvre une recherche Appstore.
    private val CATALOG = listOf(
        StoreEntry("Netflix", "Séries et films", 0xFFE50914, "com.netflix.ninja"),
        StoreEntry("Disney+", "Disney, Marvel, Star Wars", 0xFF113CCF, "com.disney.disneyplus"),
        StoreEntry("YouTube", "Vidéos sur grand écran", 0xFFCC0000, "com.amazon.firetv.youtube"),
        StoreEntry("Canal+", "Films, séries et sport", 0xFF2B2B2B),
        StoreEntry("Spotify", "Musique en streaming", 0xFF1DB954, "com.spotify.tv.android"),
        StoreEntry("Apple TV", "Apple TV+ sur Fire TV", 0xFF48484A),
        StoreEntry("Max", "Séries HBO et films", 0xFF002BE7),
        StoreEntry("Crunchyroll", "Animes en streaming", 0xFFF47521),
        StoreEntry("Twitch", "Streams en direct", 0xFF9146FF),
        StoreEntry("Plex", "Ta médiathèque perso", 0xFFE5A00D, "com.plexapp.android"),
        StoreEntry("Jellyfin", "Serveur média libre", 0xFF00A4DC, "org.jellyfin.androidtv"),
        StoreEntry("Kodi", "Centre multimédia", 0xFF17B2E7, "org.xbmc.kodi"),
        StoreEntry("VLC", "Lecteur vidéo universel", 0xFFFF8800, "org.videolan.vlc"),
        StoreEntry("Pluto TV", "TV gratuite", 0xFF3A3A3C),
        StoreEntry("TF1+", "Replay et direct", 0xFF0F4C9E),
        StoreEntry("france.tv", "Replay du service public", 0xFF2A2A7A),
        StoreEntry("ARTE", "Culture en streaming", 0xFFE8590C),
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Suppress("DEPRECATION")
    fun load(context: Context): List<TvApp> {
        val pm = context.packageManager
        val pinned = prefs(context).getStringSet(PINNED, emptySet()) ?: emptySet()
        val seen = HashSet<String>()
        val apps = ArrayList<TvApp>()

        // Apps Android TV / Fire TV d'abord, puis apps « classiques » installées en sideload.
        for (category in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (info in pm.queryIntentActivities(query, 0)) {
                val pkg = info.activityInfo.packageName
                if (pkg == context.packageName || !seen.add(pkg)) continue
                apps += buildApp(pm, info, pkg in pinned)
            }
        }

        val sorted = apps.sortedWith(
            compareByDescending<TvApp> { it.pinned }.thenBy { it.label.lowercase() }
        )

        val settings = TvApp(
            key = SETTINGS_KEY,
            label = "Réglages",
            intent = Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            image = null,
            isBanner = false,
            accent = Color(0xFF636366),
            glyph = "⚙",
        )

        val installedLabels = sorted.map { it.label.lowercase() }.toSet()
        return sorted + settings + storeTiles(pm, seen, installedLabels)
    }

    private fun storeTiles(
        pm: PackageManager,
        installedPackages: Set<String>,
        installedLabels: Set<String>,
    ): List<TvApp> {
        val tiles = ArrayList<TvApp>()

        // Tuile « Appstore Amazon » : ouvre le magasin complet (si présent).
        val appstore = pm.getLeanbackLaunchIntentForPackage(APPSTORE_PKG)
            ?: pm.getLaunchIntentForPackage(APPSTORE_PKG)
        if (appstore != null) {
            tiles += TvApp(
                key = "store:appstore",
                label = "Appstore Amazon",
                intent = appstore.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                image = null,
                isBanner = false,
                accent = Color(0xFFFF9900),
                glyph = "Appstore",
                badge = "Amazon",
                tagline = "Parcourir tout le catalogue",
                store = true,
            )
        }

        for (e in CATALOG) {
            // On masque ce qui est déjà installé.
            if (e.pkg != null && e.pkg in installedPackages) continue
            if (e.name.lowercase() in installedLabels) continue

            val uri = if (e.pkg != null) {
                "amzn://apps/android?p=${e.pkg}"
            } else {
                "amzn://apps/android?s=" + Uri.encode(e.name)
            }
            tiles += TvApp(
                key = "store:" + e.name,
                label = e.name,
                intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                image = null,
                isBanner = false,
                accent = Color(e.color),
                glyph = e.name,
                badge = "Appstore",
                tagline = e.tagline + " · OK pour ouvrir la fiche",
                store = true,
            )
        }
        return tiles
    }

    private fun buildApp(pm: PackageManager, info: ResolveInfo, pinned: Boolean): TvApp {
        val ai = info.activityInfo
        val banner = ai.loadBanner(pm) ?: ai.applicationInfo.loadBanner(pm)
        val bitmap: Bitmap? = runCatching {
            if (banner != null) banner.toBitmap(480, 270)
            else info.loadIcon(pm).toBitmap(256, 256)
        }.getOrNull()

        val intent = Intent(Intent.ACTION_MAIN)
            .setComponent(ComponentName(ai.packageName, ai.name))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)

        return TvApp(
            key = ai.packageName,
            label = info.loadLabel(pm).toString(),
            intent = intent,
            image = bitmap?.asImageBitmap(),
            isBanner = banner != null,
            accent = bitmap?.let { accentFrom(it) } ?: FALLBACK,
            pinned = pinned,
            blurred = bitmap?.let { runCatching { blurredFrom(it).asImageBitmap() }.getOrNull() },
        )
    }

    fun launch(context: Context, app: TvApp) {
        runCatching { context.startActivity(app.intent) }.onFailure {
            val msg = if (app.store) "Appstore Amazon introuvable sur cet appareil"
            else "Impossible d'ouvrir ${app.label}"
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    fun togglePin(context: Context, key: String) {
        if (key == SETTINGS_KEY || key.startsWith("store:")) return
        val p = prefs(context)
        val set = HashSet(p.getStringSet(PINNED, emptySet()) ?: emptySet())
        if (!set.add(key)) set.remove(key)
        p.edit().putStringSet(PINNED, set).apply()
    }

    /**
     * Flou « maison » qui marche sur toutes les versions d'Android : on réduit l'image
     * par paliers (moyenne des pixels), puis on la ré-agrandit avec lissage.
     */
    private fun blurredFrom(bitmap: Bitmap): Bitmap {
        var cur = bitmap
        while (cur.width > 64) {
            cur = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
        }
        repeat(2) {
            cur = Bitmap.createScaledBitmap(cur, cur.width * 2, cur.height * 2, true)
        }
        return cur
    }

    /** Couleur moyenne de l'image, ajustée pour faire un beau fond sombre. */
    private fun accentFrom(bitmap: Bitmap): Color {
        val small = Bitmap.createScaledBitmap(bitmap, 16, 16, true)
        var r = 0L
        var g = 0L
        var b = 0L
        var n = 0
        for (y in 0 until 16) {
            for (x in 0 until 16) {
                val p = small.getPixel(x, y)
                if (AndroidColor.alpha(p) > 40) {
                    r += AndroidColor.red(p)
                    g += AndroidColor.green(p)
                    b += AndroidColor.blue(p)
                    n++
                }
            }
        }
        if (n == 0) return FALLBACK
        val avg = AndroidColor.rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
        val hsv = FloatArray(3)
        AndroidColor.colorToHSV(avg, hsv)
        if (hsv[1] > 0.12f) hsv[1] = hsv[1].coerceIn(0.35f, 0.85f)
        hsv[2] = hsv[2].coerceIn(0.35f, 0.7f)
        return Color(AndroidColor.HSVToColor(hsv))
    }
}
